from setuptools import setup

setup(name="rahul@package",
version='2.0.0',
description="short description",
long_description="my long description" ,
author="harry",
packages=["rahulpackage"],
install_requires=[]
)